var searchData=
[
  ['taskmanager3_0',['TaskManager3',['../namespace_task_manager3.html',1,'']]]
];
