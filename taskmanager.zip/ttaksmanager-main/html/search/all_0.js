var searchData=
[
  ['dispose_0',['Dispose',['../class_task_manager3_1_1_form1.html#ae28810759fb7b060be15ae53664b15c8',1,'TaskManager3::Form1']]]
];
